OTF: Hennigar (Regular and Italic)
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Hennigar is a Neo Grotesque sans designed for display text and headlines. While similar to Impact and Amsterdam at first sight many of the rounded letters are based on the appearance of the letter O with very little variation in width. Because of it's condensed nature the aperatures are narrow 
with extenders that dip well below the base line. Similarly many of the lowercase characters are based on the lowercase o. Terminals and tails always point east/west giving the entire alphabet a very uniform appearance. Basic latin, extended latin, diacritics, punctuation, math symbols, science 
symbols,Greek, Cyrillic, ligatures, fractions, alternates, and kerning are included in the full version. Kerning support for Macedonian and Serbian is included via alternate substitutions along with proper italics for Russian. Demo version will feature basic latin, some accents, and punctuation.

Complete regular version + Italic version are included with purchase of commercial license or $25 payment via PayPal. Please note that this $25 is for PERSONAL use only and does not constitute a commercial license.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info and terms. I also design custom 
fonts for companies, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: display, font, typeface, publishing, logo, title, book, cover, magazine, company, style, brand, mystery, meme, poster, headline, title, Roman, diacritics, French, Polish, Sharkshock, German, Portuguese, European, neo grotesque, realist, width, condensed, compact, impact, lowercase, italic,
Greek, Cyrillic, Russian, uniform, consistent, clean, thick, dense




