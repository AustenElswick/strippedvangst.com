export const Config = {apiUrl: 'http://54.185.129.161:8080/index.php'}
